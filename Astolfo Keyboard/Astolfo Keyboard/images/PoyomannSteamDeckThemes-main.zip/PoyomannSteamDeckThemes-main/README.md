# PoyomannSteamDeckThemes

## Currently contains:

### RGB keyboard theme
An RGB keyboard, with lots of customizability.
Both the 'rainbow' and 'deck colours' patterns were made by suchmememanyskill, who also made the CSS loader

https://user-images.githubusercontent.com/48649272/179416332-b47eed4c-5b42-4b7d-bb40-b1b69de6288c.mp4

https://user-images.githubusercontent.com/48649272/179416334-4b7c7eb5-faa7-4a7d-8ca2-847f70ead44a.mp4

https://user-images.githubusercontent.com/48649272/179416331-57e73a48-46e6-40af-b99b-7f9ec7bd253f.mp4


### Astolfo keyboard theme
A pink Astolfo keyboard, made for fun.![AstolfoBlack](https://user-images.githubusercontent.com/48649272/179416386-eb74df5b-94de-444a-becb-28dfed7eb7a1.png)
![AstolfoPink](https://user-images.githubusercontent.com/48649272/179416388-fdf00675-2f32-4da8-b67c-3fe9eaff30bf.png)
